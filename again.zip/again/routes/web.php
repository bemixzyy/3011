<?php

use App\Http\Controllers\WebController;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\ItemController;

Route::resource('items', ItemController::class);
Route::get('/',[WebController::class,"home"]);
Route::get('/category/{id}',[WebController::class,"category"]);
Route::get("/about-us",[WebController::class,"about"]);