@extends('layouts.app')

@section('content')
<h1>Item List</h1>
<a href="{{ route('items.create') }}">Add New Item</a>
@if(session('success'))
    <div>{{ session('success') }}</div>
@endif
<table>
    <thead>
        <tr>
            <th>Item Code</th>
            <th>Item Name</th>
            <th>Quantity</th>
            <th>Expired Date</th>
            <th>Note</th>
            <th>Actions</th>
        </tr>
    </thead>
    <tbody>
        @foreach($items as $item)
        <tr>
            <td>{{ $item->item_code }}</td>
            <td>{{ $item->item_name }}</td>
            <td>{{ $item->quantity }}</td>
            <td>{{ $item->expired_date }}</td>
            <td>{{ $item->note }}</td>
            <td>
                <a href="{{ route('items.edit', $item) }}">Edit</a>
            </td>
        </tr>
        @endforeach
    </tbody>
</table>
@endsection