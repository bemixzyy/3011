@extends('layouts.app')

@section('content')
<h1>Add New Item</h1>
<form action="{{ route('items.store') }}" method="POST">
    @csrf
    <label for="item_code">Item Code:</label>
    <input type="text" name="item_code" required>
    <label for="item_name">Item Name:</label>
    <input type="text" name="item_name" required>
    <label for="quantity">Quantity:</label>
    <input type="number" step="0.01" name="quantity">
    <label for="expired_date">Expired Date:</label>
    <input type="date" name="expired_date">
    <label for="note">Note:</label>
    <input type="text" name="note">
    <button type="submit">Add Item</button>
</form>
@endsection