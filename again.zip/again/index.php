<?php
// Database connection
$mysqli = new mysqli("localhost", "username", "password", "v_store");

// Fetch contacts from the database
$result = $mysqli->query("SELECT * FROM item_sale");
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Index</title>
</head>
<body>
<h1 class="text-center">Phone Book</h1>
<a href="add_contact.php">Add New Contact</a>
<table class="table">
    <thead>
    <tr>
        <th>ID</th>
        <th>Item Code</th>
        <th>Item Name</th>
        <th>Quantity</th>
        <th>Expired date</th>
        <th>Note</th>
    </tr>
    </thead>
    <tbody>
    <?php foreach ($contacts as $contact) { ?>
    <tr>
        <td><?php echo $contact['id']; ?></td>
        <td><?php echo $contact['Item Code']; ?></td>
        <td><?php echo $contact['Item Name']; ?></td>
        <td><?php echo $contact['Quantity']; ?></td>
        <td>
            <a href="edit_contact.php?id=<?php echo $contact['id']; ?>">Edit</a>
            <a href="delete_contact.php?id=<?php echo $contact['id']; ?>">Delete</a>
        </td>
    </tr>
    </tbody>

    <?php } ?>
</table>
</body>
</html>
