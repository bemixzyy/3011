<aside class="col-3">
                <ul class="list-group">
                    <li class="list-group-item">Orders</li>
                    <li class="list-group-item">Customers</li>
                    <li class="list-group-item">Products</li>
                    <li class="list-group-item">Categories</li>
                    <li class="list-group-item">Reviews</li>
                </ul>
            </aside>